
const express = require('express');
const request = require('request');
const url = require('url');
const path = require('path');
const app = express();

const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));

app.get('/proxy', (req, res) => {
  const targetUrl = req.query.url;
  if (!targetUrl) return res.status(400).send('Falta el parámetro "url".');

  const ext = targetUrl.split('?')[0].split('.').pop();
  const headers = {
    'User-Agent': req.query.ua || 'Mozilla/5.0',
    'Referer': req.query.referer || '',
    'Origin': req.query.origin || ''
  };

  const options = { url: targetUrl, headers };

  if (ext === 'm3u8') {
    request(options, (err, response, body) => {
      if (err || !body) return res.status(500).send('Error al cargar el M3U8.');
      const parsed = url.parse(targetUrl);
      const baseUrl = `${parsed.protocol}//${parsed.host}${parsed.pathname.substring(0, parsed.pathname.lastIndexOf('/') + 1)}`;
      const modified = body.replace(/(.*\.ts)/g, match => {
        const tsUrl = match.startsWith('http') ? match : baseUrl + match;
        return `/proxy?url=${encodeURIComponent(tsUrl)}&ua=${encodeURIComponent(headers['User-Agent'])}&referer=${encodeURIComponent(headers['Referer'])}&origin=${encodeURIComponent(headers['Origin'])}`;
      });
      res.setHeader('Content-Type', 'application/vnd.apple.mpegurl');
      res.send(modified);
    });
  } else {
    request(options)
      .on('error', () => res.status(500).send('Error al acceder al recurso.'))
      .pipe(res);
  }
});

app.listen(PORT, () => console.log(`Proxy corriendo en http://localhost:${PORT}`));
